package com.example.lista_zakupow_projekt

interface ProduktItemClickListener{
    fun editProduktItem(produktItem: ProduktItem)
    fun deleteProduktItem(produktItem: ProduktItem)
}